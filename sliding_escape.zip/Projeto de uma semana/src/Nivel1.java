import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.EventQueue;
import java.awt.Graphics;
import javax.swing.*;
import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.URL;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Window.Type;

public class Nivel1 extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Nivel1 frame = new Nivel1();
					frame.setUndecorated(true);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Nivel1() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(320, 0, 800, 900);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel parede7 = new JLabel("");
		parede7.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede7.setBackground(Color.BLACK);
		parede7.setBounds(780, 200, 20, 680);
		contentPane.add(parede7);
		
		JLabel parede = new JLabel("");
		parede.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede.setBackground(Color.BLACK);
		parede.setBounds(0, 0, 1440, 100);
		contentPane.add(parede);
		
		JLabel parede2 = new JLabel("");
		parede2.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede2.setBackground(Color.BLACK);
		parede2.setBounds(500, 100, 300, 100);
		contentPane.add(parede2);
		
		JLabel parede3 = new JLabel("");
		parede3.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede3.setBackground(Color.BLACK);
		parede3.setBounds(400, 400, 400, 100);
		contentPane.add(parede3);
		
		JLabel parede4 = new JLabel("");
		parede4.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede4.setBackground(Color.BLACK);
		parede4.setBounds(0, 800, 200, 100);
		contentPane.add(parede4);
		
		JLabel parede6 = new JLabel("");
		parede6.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede6.setBackground(Color.BLACK);
		parede6.setBounds(0, 100, 20, 700);
		contentPane.add(parede6);
		
		JLabel parede8 = new JLabel("");
		parede8.setIcon(new ImageIcon("C:\\Users\\117956\\Desktop\\1440x900-black-solid-color-background.jpg"));
		parede8.setBackground(Color.BLACK);
		parede8.setBounds(200, 880, 700, 20);
		contentPane.add(parede8);
		
		URL url =Nivel1.class.getResource("giphy.gif");
		ImageIcon ImageIcon=new ImageIcon(url);
		JLabel label=new JLabel(ImageIcon);
		label.setBounds(200,400,100,100);
		contentPane.add(label);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.CYAN);
		panel.setBounds(400, 500, 380, 5);
		contentPane.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.CYAN);
		panel_1.setBounds(200, 875, 600, 5);
		contentPane.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.CYAN);
		panel_2.setBounds(-100, 100, 600, 5);
		contentPane.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.CYAN);
		panel_3.setBounds(500, 200, 600, 5);
		contentPane.add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.CYAN);
		panel_4.setBounds(20, 795, 180, 5);
		contentPane.add(panel_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.CYAN);
		panel_5.setBounds(400, 395, 600, 5);
		contentPane.add(panel_5);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(Color.CYAN);
		panel_6.setBounds(20, 100, 5, 800);
		contentPane.add(panel_6);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(Color.CYAN);
		panel_7.setBounds(200, 795, 5, 800);
		contentPane.add(panel_7);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(Color.CYAN);
		panel_8.setBounds(395, 395, 5, 110);
		contentPane.add(panel_8);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBackground(Color.CYAN);
		panel_9.setBounds(495, 100, 5, 105);
		contentPane.add(panel_9);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBackground(Color.CYAN);
		panel_10.setBounds(775, 200, 5, 700);
		contentPane.add(panel_10);
		

	}
}
