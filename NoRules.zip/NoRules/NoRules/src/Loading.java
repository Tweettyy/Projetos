import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Loading extends JFrame {

	private JPanel contentPane;
	JLabel load = new JLabel("Loading");
	int cont=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Loading frame = new Loading();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Loading() {
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1440, 900);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		load.setBounds(5, 5, 1360, 739);
		contentPane.add(load);
		load.setFont(new Font("Sitka Subheading", Font.PLAIN, 50));
		load.setForeground(Color.WHITE);
		
		
		//timer.scheduleAtFixedRate(task, 0, 2);	
		
		
	}
	Timer timer=new Timer();
	TimerTask task =new TimerTask() {
		public void run() {
			cont++;
			if(cont<100) {
				load.setText("Loading.");

			}else if((cont>500)&&(cont<1000)) {
				
				load.setText("Loading..");

			}else if((cont>1000)&&(cont<1500)){
				load.setText("Loading...");
				
			}else if(cont>1500){
				cont=0;
		}
		}
		
	};
	
}
