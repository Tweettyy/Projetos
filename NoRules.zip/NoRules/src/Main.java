import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

public class Main extends JFrame {

	private JPanel contentPane;
	ImageIcon play=new ImageIcon(Main.class.getResource("play.png"));
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1440, 900);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel Criadores= new JLabel("Created by: Tom�s Marques & Rafael Gon�alves");
		Criadores.setBounds(10,740,300,20);
		contentPane.add(Criadores);
		Criadores.setFont(new Font("Arial", Font.PLAIN, 10));
		Criadores.setForeground(Color.WHITE);
		
		JLabel Versao= new JLabel("Vers�o: Beta 1.0");
		Versao.setBounds(1270,740,300,20);
		contentPane.add(Versao);
		Versao.setFont(new Font("Arial", Font.PLAIN, 10));
		Versao.setForeground(Color.WHITE);
		
		JLabel start = new JLabel("play");
		start.setBounds(600, 400, 350, 100);
		contentPane.add(start);
		start.setFont(new Font("Sitka Subheading", Font.PLAIN, 93));
		start.setForeground(Color.WHITE);
		start.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Loading load = new Loading();
				load.setVisible(true);
			}
		});
		
		
		
		
		
		
		
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE) {
					System.exit(0);
				}
			}
		});
	}

}
