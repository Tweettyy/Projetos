﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace FaturaçãoPSP
{
    public partial class Faturação : Form
    {
        public Faturação()
        {
            InitializeComponent();
        }
        
        public string totalName = "";
        public int totalValue = 0;
        public List<Invoice> invoices = new List<Invoice>();
        private void addInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                table.Rows.Add(nameInvoice.SelectedItem, invoices[nameInvoice.SelectedIndex].price.ToString("00€"), "Remover" );


                if (totalName.Length != 0)
                    totalName += " + ";

                totalName += invoices[nameInvoice.SelectedIndex].name;
                totalValue += invoices[nameInvoice.SelectedIndex].price;

                nameResult.Text = totalName;
                valueResult.Text = totalValue.ToString();

                nameInvoice.Text = "";
                nameInvoice.SelectedItem = null;
            }
            catch (Exception) { }
           
        }

        private void Faturação_Load(object sender, EventArgs e)
        {
            nameInvoice.AutoCompleteSource = AutoCompleteSource.AllSystemSources;
            nameInvoice.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            nameInvoice.AutoCompleteSource = AutoCompleteSource.CustomSource;

            AutoCompleteStringCollection data = new AutoCompleteStringCollection();
            table.CellClick += Table_CellClick;

            using (StreamReader r = new StreamReader(".\\Multas.json"))
            {
                string json = r.ReadToEnd();
                invoices = JsonConvert.DeserializeObject<List<Invoice>>(json);
            }
            foreach (Invoice invoice in invoices) {
                nameInvoice.AutoCompleteCustomSource.Add(invoice.name);
                nameInvoice.Items.Add(invoice.name);
            }


        }

        private void nameCopy_Click(object sender, EventArgs e)
        {
              Clipboard.SetText(nameResult.Text); 
        }

        private void valueCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(valueResult.Text);
        }

        private void Table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == table.Columns["columnRemove"].Index)
                {
                    //var rowValue = table.Rows[e.RowIndex].Cells[1].Value.ToString();
                    //totalValue = totalValue - Convert.ToInt32(rowValue.Replace("€", ""));
                    //valueResult.Text = totalValue.ToString();

                    table.Rows.RemoveAt(e.RowIndex);

                    nameResult.Text = "";
                    valueResult.Text = "";
                    totalName = "";
                    totalValue = 0;

                    foreach (DataGridViewRow row in table.Rows)
                    {
                        nameResult.Text += row.Cells[0].Value.ToString();

                        if (row.Index+1 != table.Rows.Count)
                            nameResult.Text += " + ";

                        totalName = nameResult.Text;

                        var rowValue = row.Cells[1].Value.ToString();
                        totalValue += Convert.ToInt32(rowValue.Replace("€", ""));
                        valueResult.Text = totalValue.ToString();
                    }
                    
                }
            }
            catch (Exception) { }
        }
    }
}
