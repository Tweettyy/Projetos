﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaturaçãoPSP
{
    public class Invoice
    {
        public string name { get; set; }
        public int price { get; set; }

    }
}
