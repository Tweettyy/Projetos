﻿
namespace FaturaçãoPSP
{
    partial class Faturação
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Faturação));
            this.addInvoice = new System.Windows.Forms.Button();
            this.table = new System.Windows.Forms.DataGridView();
            this.nameInvoice = new System.Windows.Forms.ComboBox();
            this.nameResult = new System.Windows.Forms.TextBox();
            this.valueResult = new System.Windows.Forms.TextBox();
            this.credits = new System.Windows.Forms.Label();
            this.nameCopy = new System.Windows.Forms.Button();
            this.valueCopy = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.columnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnRemove = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.table)).BeginInit();
            this.SuspendLayout();
            // 
            // addInvoice
            // 
            this.addInvoice.Location = new System.Drawing.Point(423, 35);
            this.addInvoice.Name = "addInvoice";
            this.addInvoice.Size = new System.Drawing.Size(120, 21);
            this.addInvoice.TabIndex = 1;
            this.addInvoice.Text = "Adicionar";
            this.addInvoice.UseVisualStyleBackColor = true;
            this.addInvoice.Click += new System.EventHandler(this.addInvoice_Click);
            // 
            // table
            // 
            this.table.AllowUserToAddRows = false;
            this.table.AllowUserToDeleteRows = false;
            this.table.AllowUserToOrderColumns = true;
            this.table.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.columnName,
            this.columnValue,
            this.columnRemove});
            this.table.Location = new System.Drawing.Point(43, 82);
            this.table.Name = "table";
            this.table.Size = new System.Drawing.Size(500, 220);
            this.table.TabIndex = 2;
            // 
            // nameInvoice
            // 
            this.nameInvoice.FormattingEnabled = true;
            this.nameInvoice.Location = new System.Drawing.Point(43, 35);
            this.nameInvoice.Name = "nameInvoice";
            this.nameInvoice.Size = new System.Drawing.Size(374, 21);
            this.nameInvoice.TabIndex = 3;
            // 
            // nameResult
            // 
            this.nameResult.Location = new System.Drawing.Point(43, 313);
            this.nameResult.Name = "nameResult";
            this.nameResult.Size = new System.Drawing.Size(408, 20);
            this.nameResult.TabIndex = 4;
            // 
            // valueResult
            // 
            this.valueResult.Location = new System.Drawing.Point(43, 339);
            this.valueResult.Name = "valueResult";
            this.valueResult.Size = new System.Drawing.Size(114, 20);
            this.valueResult.TabIndex = 5;
            // 
            // credits
            // 
            this.credits.AutoSize = true;
            this.credits.Location = new System.Drawing.Point(420, 389);
            this.credits.Name = "credits";
            this.credits.Size = new System.Drawing.Size(161, 13);
            this.credits.TabIndex = 6;
            this.credits.Text = "MadeBy: Tweety, Lukz, Atsoc24";
            // 
            // nameCopy
            // 
            this.nameCopy.Location = new System.Drawing.Point(468, 313);
            this.nameCopy.Name = "nameCopy";
            this.nameCopy.Size = new System.Drawing.Size(75, 23);
            this.nameCopy.TabIndex = 7;
            this.nameCopy.Text = "Copiar";
            this.nameCopy.UseVisualStyleBackColor = true;
            this.nameCopy.Click += new System.EventHandler(this.nameCopy_Click);
            // 
            // valueCopy
            // 
            this.valueCopy.Location = new System.Drawing.Point(468, 337);
            this.valueCopy.Name = "valueCopy";
            this.valueCopy.Size = new System.Drawing.Size(75, 23);
            this.valueCopy.TabIndex = 8;
            this.valueCopy.Text = "Copiar";
            this.valueCopy.UseVisualStyleBackColor = true;
            this.valueCopy.Click += new System.EventHandler(this.valueCopy_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(156, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "€";
            // 
            // columnName
            // 
            this.columnName.HeaderText = "Nome";
            this.columnName.Name = "columnName";
            this.columnName.Width = 300;
            // 
            // columnValue
            // 
            this.columnValue.HeaderText = "Valor";
            this.columnValue.Name = "columnValue";
            // 
            // columnRemove
            // 
            this.columnRemove.HeaderText = " ";
            this.columnRemove.Name = "columnRemove";
            this.columnRemove.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.columnRemove.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.columnRemove.Width = 58;
            // 
            // Faturação
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(584, 411);
            this.Controls.Add(this.valueResult);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.valueCopy);
            this.Controls.Add(this.nameCopy);
            this.Controls.Add(this.credits);
            this.Controls.Add(this.nameResult);
            this.Controls.Add(this.nameInvoice);
            this.Controls.Add(this.table);
            this.Controls.Add(this.addInvoice);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Faturação";
            this.Text = "Faturação";
            this.Load += new System.EventHandler(this.Faturação_Load);
            ((System.ComponentModel.ISupportInitialize)(this.table)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button addInvoice;
        private System.Windows.Forms.DataGridView table;
        private System.Windows.Forms.ComboBox nameInvoice;
        private System.Windows.Forms.TextBox nameResult;
        private System.Windows.Forms.TextBox valueResult;
        private System.Windows.Forms.Label credits;
        private System.Windows.Forms.Button nameCopy;
        private System.Windows.Forms.Button valueCopy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnValue;
        private System.Windows.Forms.DataGridViewButtonColumn columnRemove;
    }
}

