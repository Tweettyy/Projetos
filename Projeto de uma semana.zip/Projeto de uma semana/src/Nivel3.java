import javax.swing.*;
import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.awt.geom.Area;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Window.Type;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Nivel3 extends JFrame {

	//Variaveis
	private JPanel contentPane;
	public static Nivel3 frame = new Nivel3();
	int dire�ao=2;
	boolean flag=false;
	int cont=0;
	boolean flag2=false;
	boolean flagchoque=false;
	boolean flagchoque2=false;
	ImageIcon morte=new ImageIcon(Nivel3.class.getResource("explosao.gif"));
	ImageIcon parede =new ImageIcon(Nivel3.class.getResource("black.jpg"));
	ImageIcon spikecima=new ImageIcon(Nivel3.class.getResource("spikeu.png"));
	ImageIcon spikebaixo=new ImageIcon(Nivel3.class.getResource("spiked.png"));
	ImageIcon portal=new ImageIcon(Nivel3.class.getResource("portalroxo.gif"));
	ImageIcon restarti=new ImageIcon(Nivel3.class.getResource("restart2.png"));
	ImageIcon pontos=new ImageIcon(Nivel3.class.getResource("pontos.gif"));
	ImageIcon estrelavazia=new ImageIcon(Nivel3.class.getResource("star.png"));
	ImageIcon estrela=new ImageIcon(Nivel3.class.getResource("star_1.png"));
	ImageIcon menu=new ImageIcon(Nivel3.class.getResource("list.png"));
	ImageIcon choque=new ImageIcon(Nivel3.class.getResource("choqueteste.gif"));
	ImageIcon bolha=new ImageIcon(Nivel3.class.getResource("bolha.png"));
	
	ImageIcon player1=new ImageIcon(Nivel3.class.getResource("player1.png"));
	

	//Frame
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				
					frame.setUndecorated(true);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	//Intersects
	public boolean intersetscima(JLabel player, JPanel panel) {
		Area area1 = new Area(player.getBounds());
		Area area2= new Area(panel.getBounds());
		
		return area1.intersects(area2.getBounds());
	}
	public boolean intersetsbaixo(JLabel player, JPanel panel_1) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(panel_1.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersetsesquerda(JLabel player, JPanel panel_6) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(panel_6.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersetsdireita(JLabel player, JPanel panel_10) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(panel_10.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersetsspikes(JLabel player, JLabel spike) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(spike.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean Fim(JLabel player, JLabel fim) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(fim.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersectpontos(JLabel player, JLabel ponto1) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(ponto1.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersectchoque(JLabel player, JLabel choquetrap) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(choquetrap.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}

	//Cria�ao 
	public Nivel3() {
		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setIconImage(estrela.getImage());
		setBounds(320, 0, 800, 900);
		contentPane = new JPanel();
		
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lista = new JLabel(menu);
		lista.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuPausa pausa=new MenuPausa();
				pausa.setVisible(true);
				pausa.setBackground(new Color(1.0f,1.0f,1.0f,0.2f));


				
			}
		});
		
		JPanel panel_22 = new JPanel();
		panel_22.setBackground(Color.BLACK);
		panel_22.setBounds(244, 559, 20, 43);
		contentPane.add(panel_22);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBackground(Color.CYAN);
		panel_12.setBounds(275, 100, 505, 5);
		contentPane.add(panel_12);
		lista.setBackground(Color.WHITE);
		lista.setBounds(740, 10, 40, 40);
		contentPane.add(lista);
		
		JLabel estrela3 = new JLabel(estrelavazia);
		estrela3.setBackground(Color.WHITE);
		estrela3.setBounds(400, 10, 40, 40);
		contentPane.add(estrela3);
		
		JLabel estrela1 = new JLabel(estrelavazia);
		estrela1.setBackground(Color.WHITE);
		estrela1.setBounds(319, 10, 40, 40);
		contentPane.add(estrela1);
		
		JLabel estrela2 = new JLabel(estrelavazia);
		estrela2.setBackground(Color.WHITE);
		estrela2.setBounds(360, 10, 40, 40);
		contentPane.add(estrela2);
		
		

		JLabel level = new JLabel("Level: 3");
		level.setFont(new Font("Buxton Sketch", Font.BOLD | Font.ITALIC, 25));
		level.setForeground(Color.WHITE);
		level.setHorizontalAlignment(SwingConstants.CENTER);
		level.setBounds(20, 10, 99, 50);
		contentPane.add(level);
		
		if(Menu.player==3){
			 player1=new ImageIcon(Nivel3.class.getResource("player3.png"));
		}
		else{
			 player1=new ImageIcon(Nivel3.class.getResource("player4.png"));
		}
		JLabel player = new JLabel(player1);
		player.setBounds(290, 500, 70, 70);
		contentPane.add(player);
		
		JLabel ponto1 = new JLabel(pontos);
		MenuClear.flagc1=true;
		ponto1.setBackground(Color.WHITE);
		ponto1.setBounds(30, 658, 35, 35);
		contentPane.add(ponto1);
		
		JLabel ponto2 = new JLabel(pontos);
		MenuClear.flagc2=true;
		ponto2.setBackground(Color.WHITE);
		ponto2.setBounds(285, 110, 35, 35);
		contentPane.add(ponto2);
		
		JLabel ponto3 = new JLabel(pontos);
		MenuClear.flagc3=true;
		ponto3.setBackground(Color.WHITE);
		ponto3.setBounds(145, 830, 35, 35);
		contentPane.add(ponto3);
		
		
		JLabel restart = new JLabel(restarti);
		restart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				player.setLocation(290, 500);
				estrela1.setIcon(estrelavazia);
				estrela2.setIcon(estrelavazia);
				estrela3.setIcon(estrelavazia);
				ponto1.setVisible(true);
				ponto2.setVisible(true);
				ponto3.setVisible(true);
			}
		});
		restart.setBackground(Color.WHITE);
		restart.setBounds(680, 10, 40, 40);
		contentPane.add(restart);
		
		JLabel parede7 = new JLabel(parede);
		parede7.setBackground(Color.BLACK);
		parede7.setBounds(780, 100, 20, 791);
		contentPane.add(parede7);
		
		JLabel parede1 = new JLabel(parede);
		parede1.setBounds(0, 0, 1440, 100);
		contentPane.add(parede1);
		
		JLabel parede6 = new JLabel(parede);
		parede6.setBounds(0, 100, 20, 700);
		contentPane.add(parede6);
		
		JLabel parede8 = new JLabel(parede);
		parede8.setBounds(0, 880, 900, 20);
		contentPane.add(parede8);
		
		
		JLabel fim=new JLabel(portal);
		fim.setBounds(350,623,90,90);
		contentPane.add(fim);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.CYAN);
		panel_1.setBounds(500, 875, 300, 5);
		contentPane.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.CYAN);
		panel_2.setBounds(-100, 100, 300, 5);
		contentPane.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.CYAN);
		panel_3.setBounds(200, 200, 80, 5);
		contentPane.add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.CYAN);
		panel_4.setBounds(325, 800, 180, 5);
		contentPane.add(panel_4);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(Color.CYAN);
		panel_6.setBounds(20, 100, 5, 800);
		contentPane.add(panel_6);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(Color.CYAN);
		panel_7.setBounds(500, 800, 5, 800);
		contentPane.add(panel_7);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBackground(Color.CYAN);
		panel_9.setBounds(200, 100, 5, 105);
		contentPane.add(panel_9);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBackground(Color.CYAN);
		panel_10.setBounds(775, 100, 5, 800);
		contentPane.add(panel_10);
		
		JLabel spike4 = new JLabel(spikebaixo);
		spike4.setBounds(630, 95, 50, 50);
		contentPane.add(spike4);
		
		JLabel spike10 = new JLabel(spikebaixo);
		spike10.setBounds(581, 95, 50, 50);
		contentPane.add(spike10);
		
		JLabel spike5 = new JLabel(spikebaixo);
		spike5.setBounds(680, 95, 50, 50);
		contentPane.add(spike5);
		
		JLabel spike6 = new JLabel(spikebaixo);
		spike6.setBounds(729, 95, 50, 50);
		contentPane.add(spike6);
		
		
		
		JLabel death=new JLabel(morte);
		death.setBounds(1000,492,500,500);
		death.setVisible(false);
		contentPane.add(death);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBackground(Color.CYAN);
		panel_11.setBounds(275, 100, 5, 105);
		contentPane.add(panel_11);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.CYAN);
		panel.setBounds(324, 800, 5, 300);
		contentPane.add(panel);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.CYAN);
		panel_5.setBounds(20, 875, 309, 5);
		contentPane.add(panel_5);
		
		JLabel spike2 = new JLabel(spikecima);
		spike2.setBounds(80, 830, 50, 50);
		contentPane.add(spike2);
		
		JLabel spike3 = new JLabel(spikecima);
		spike3.setBounds(730, 830, 50, 50);
		contentPane.add(spike3);
		
		
		
		JLabel spike1 = new JLabel(spikecima);
		spike1.setBounds(30, 830, 50, 50);
		contentPane.add(spike1);
		
		JLabel spike7 = new JLabel(spikecima);
		spike7.setBounds(680, 830, 50, 50);
		contentPane.add(spike7);
		
		JLabel spike8 = new JLabel(spikecima);
		spike8.setBounds(630, 830, 50, 50);
		contentPane.add(spike8);
		
		JLabel spike9 = new JLabel(spikecima);
		spike9.setBounds(580, 830, 50, 50);
		contentPane.add(spike9);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(Color.CYAN);
		panel_8.setBounds(239, 372, 5, 246);
		contentPane.add(panel_8);
		
		JPanel panel_13 = new JPanel();
		panel_13.setBackground(Color.CYAN);
		panel_13.setBounds(240, 372, 248, 5);
		contentPane.add(panel_13);
		
		JPanel panel_14 = new JPanel();
		panel_14.setBackground(Color.CYAN);
		panel_14.setBounds(240, 613, 248, 5);
		contentPane.add(panel_14);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBackground(Color.CYAN);
		panel_15.setBounds(483, 576, 5, 42);
		contentPane.add(panel_15);
		
		JPanel panel_16 = new JPanel();
		panel_16.setBackground(Color.CYAN);
		panel_16.setBounds(483, 372, 5, 84);
		contentPane.add(panel_16);
		
		JPanel panel_17 = new JPanel();
		panel_17.setBackground(Color.CYAN);
		panel_17.setBounds(275, 402, 180, 5);
		contentPane.add(panel_17);
		
		JPanel panel_18 = new JPanel();
		panel_18.setBackground(Color.CYAN);
		panel_18.setBounds(275, 576, 213, 5);
		contentPane.add(panel_18);
		
		JPanel panel_19 = new JPanel();
		panel_19.setBackground(Color.CYAN);
		panel_19.setBounds(275, 402, 5, 178);
		contentPane.add(panel_19);
		
		JPanel panel_20 = new JPanel();
		panel_20.setBackground(Color.CYAN);
		panel_20.setBounds(453, 450, 35, 5);
		contentPane.add(panel_20);
		
		JPanel panel_21 = new JPanel();
		panel_21.setBackground(Color.CYAN);
		panel_21.setBounds(453, 403, 5, 50);
		contentPane.add(panel_21);
		
		JPanel panel_23 = new JPanel();
		panel_23.setBackground(Color.BLACK);
		panel_23.setBounds(465, 377, 20, 43);
		contentPane.add(panel_23);
		
		JLabel bolha1 = new JLabel(bolha);
		bolha1.setBackground(Color.WHITE);
		bolha1.setBounds(219, 559, 35, 35);
		contentPane.add(bolha1);
		
		JLabel bolha2 = new JLabel(bolha);
		bolha2.setBackground(Color.WHITE);
		bolha2.setBounds(10, 559, 35, 35);
		contentPane.add(bolha2);
		
		JLabel choque1 = new JLabel(choque);
		choque1.setBounds(35, 567, 190, 27);
		contentPane.add(choque1);
		
		JLabel bolha4 = new JLabel(bolha);
		bolha4.setBackground(Color.WHITE);
		bolha4.setBounds(755, 372, 35, 35);
		contentPane.add(bolha4);
		
		JLabel bolha3 = new JLabel(bolha);
		bolha3.setBackground(Color.WHITE);
		bolha3.setBounds(475, 372, 35, 35);
		contentPane.add(bolha3);
		
		JLabel choque2 = new JLabel(choque);
		choque2.setBounds(500, 372, 252, 27);
		contentPane.add(choque2);
		
		
		
		//Timer2
				Timer timer2=new Timer();
				TimerTask task2 =new TimerTask() {
					@Override
					public void run() {
						cont++;
						if ((cont>0)&&(cont<70)) {
							flag2=true;
							spike10.setLocation(spike10.getX(),95);
							spike4.setLocation(spike4.getX(),95);
							spike5.setLocation(spike5.getX(),95);
							spike6.setLocation(spike6.getX(),95);
						}	
					    if ((cont>70)&&(cont<110)) {
					    	spike10.setLocation(spike10.getX(),spike10.getY()-1);
					    	spike4.setLocation(spike4.getX(),spike4.getY()-1);
					    	spike5.setLocation(spike5.getX(),spike5.getY()-1);
					    	spike6.setLocation(spike6.getX(),spike6.getY()-1);
					    }
					    if (cont>100) {
					    	flag2=false;
					    }
					    
					   
						if (cont==210) {
							
							cont=0;
						}
						
						
						if((cont>0)&&(cont<100)) {
							choque1.setVisible(true);
							choque2.setVisible(false);
							flagchoque=true;
							flagchoque2=false;
						}
						if((cont>100)&&(cont<200)) {
							choque1.setVisible(false);
							choque2.setVisible(true);
							flagchoque=false;
							flagchoque2=true;
						}
						
						
						
						
					}
				};
				
				timer2.scheduleAtFixedRate(task2, 0, 10);
		
		
		
		//Timer
		Timer timer=new Timer();
		TimerTask task =new TimerTask() {
			public void run() {
				if (MenuPausa.flagrestart==true) {
					player.setLocation(290, 500);
					estrela1.setIcon(estrelavazia);
					estrela2.setIcon(estrelavazia);
					estrela3.setIcon(estrelavazia);
					ponto1.setVisible(true);
					ponto2.setVisible(true);
					ponto3.setVisible(true);
					cont=0;
					MenuPausa.flagrestart=false;
				}
				 if ((intersectchoque(player,choque1)&&(flagchoque==true))||(intersectchoque(player,choque2)&&(flagchoque2==true))) {
					    player.setVisible(false);
						dire�ao=2;
						death.setLocation(player.getX()-150, player.getY()-200);
						death.setVisible(true);
						try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						death.setVisible(false);
						player.setLocation(290, 500);
						player.setVisible(true);
						estrela1.setIcon(estrelavazia);
						estrela2.setIcon(estrelavazia);
						estrela3.setIcon(estrelavazia);
						ponto1.setVisible(true);
						ponto2.setVisible(true);
						ponto3.setVisible(true);		
					}
				
                if (intersectpontos(player,ponto1)) {
					ponto1.setVisible(false);
					estrela1.setIcon(estrela);
				}
                if (intersectpontos(player,ponto2)) {
                    ponto2.setVisible(false);
                    estrela2.setIcon(estrela);

                }
                if (intersectpontos(player,ponto3)) {
					ponto3.setVisible(false);
					estrela3.setIcon(estrela);
				}
                if ((intersetsspikes(player,spike5)||intersetsspikes(player,spike4)||intersetsspikes(player,spike5)||intersetsspikes(player,spike10))&&(flag2==true)||intersetsspikes(player,spike1)||intersetsspikes(player,spike2)||intersetsspikes(player,spike3)||intersetsspikes(player,spike7)||intersetsspikes(player,spike8)||intersetsspikes(player,spike9)) {
					player.setLocation(player.getX(), player.getY()-5);
					player.setVisible(false);
					dire�ao=2;
					death.setLocation(player.getX()-150, player.getY()-200);
					death.setVisible(true);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					death.setVisible(false);
					player.setLocation(290, 500);
					player.setVisible(true);
					estrela1.setIcon(estrelavazia);
					estrela2.setIcon(estrelavazia);
					estrela3.setIcon(estrelavazia);
					ponto1.setVisible(true);
					ponto2.setVisible(true);
					ponto3.setVisible(true);		
				}
                if (Fim(player,fim)) {
					timer.cancel();
					
				        MenuClear.contnivel=3;
				       MenuClear clear=new MenuClear();
				       clear.setVisible(true);
				       clear.setBackground(new Color(1.0f,1.0f,1.0f,0.2f));
				}
                
				switch(dire�ao) {
				
				case 1:
					
					
					if(intersetscima(player,panel_3) ||intersetscima(player,panel_2) ||intersetscima(player,panel_12)||intersetscima(player,panel_17)||intersetscima(player,panel_14)||intersetscima(player,panel_20) ) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX(), player.getY()+5);
						
						
						
					}
					else {
						player.setLocation(player.getX(), player.getY()-5);
					}
					
					break;
				case 2:
					
					if(intersetsbaixo(player,panel_1)||intersetsbaixo(player,panel_5)||intersetsbaixo(player,panel_4)||intersetsbaixo(player,panel_13)||intersetsbaixo(player,panel_18)) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX(), player.getY()-5);
					
						
					}
					
					else {
					       player.setLocation(player.getX(), player.getY()+5);
					}
					break;
				case 3:
					
					if(intersetsesquerda(player,panel_6)||intersetsesquerda(player,panel_19)||intersetsesquerda(player,panel_11)) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX()+1, player.getY());
						
					}
					else {
					      player.setLocation(player.getX()-5, player.getY());
					break;
					}
				case 4:
					
					if(intersetsdireita(player,panel_8)||intersetsdireita(player,panel_9)||intersetsdireita(player,panel_10)||intersetsdireita(player,panel_21)||intersetsdireita(player,panel)) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX()-1, player.getY());	
						
					}
					else {
					     player.setLocation(player.getX()+5, player.getY());	
					}
					break;
				}	
			}
			
		};
		
		
		
		
		//Key
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent ke) {
				if (flag==false) {
					
			
				if ((ke.getKeyCode()==KeyEvent.VK_W)||(ke.getKeyCode()==KeyEvent.VK_UP)) {
					dire�ao=1;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);	
				}
				if ((ke.getKeyCode()==KeyEvent.VK_S)||(ke.getKeyCode()==KeyEvent.VK_DOWN)) {
					dire�ao=2;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);
					
				}
				if ((ke.getKeyCode()==KeyEvent.VK_A)||(ke.getKeyCode()==KeyEvent.VK_LEFT)) {
					dire�ao=3;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);
				}
				if ((ke.getKeyCode()==KeyEvent.VK_D)||(ke.getKeyCode()==KeyEvent.VK_RIGHT)) {
					dire�ao=4;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);
				}
				if (ke.getKeyCode()==KeyEvent.VK_ESCAPE) {
					timer.cancel();
					System.exit(0);
				}
				}
			}
		});


	}
}
