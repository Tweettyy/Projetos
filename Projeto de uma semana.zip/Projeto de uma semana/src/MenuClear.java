import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.Icon;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuClear extends JFrame {

	ImageIcon menui=new ImageIcon(Nivel2.class.getResource("listaneon.png"));
	ImageIcon restarti=new ImageIcon(Nivel2.class.getResource("restartneon.png"));
	ImageIcon resumei=new ImageIcon(Nivel2.class.getResource("resume.png"));
	ImageIcon crystal=new ImageIcon(Nivel2.class.getResource("crystal.png"));
	ImageIcon crystalvazio=new ImageIcon(Nivel2.class.getResource("crystalvazio.png"));
	public static boolean flagrestart=false;
	private JPanel contentPane;
	public static int contnivel=0;
	public static int contcrystal=0;
	public static boolean flagniveis=false;
	public static boolean flagc1=false;
	public static boolean flagc2=false;
	public static boolean flagc3=false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuClear frame = new MenuClear();
					frame.setUndecorated(true);
					frame.setBackground(new Color(1.0f,1.0f,1.0f,0.2f));
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuClear() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(283, 0, 800, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0f, 0f, 0f,0.7f));
		panel.setBounds(0, 370, 800, 230);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel menu = new JLabel(menui);
		menu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		menu.setBounds(250, 130, 90, 90);
		panel.add(menu);
		
		
		
		JLabel ponto1 = new JLabel(crystalvazio);
		if (flagc1==true) {
			
			ponto1.setIcon(crystal);
			flagc1=false;
		}
		ponto1.setBounds(240, 20, 90, 90);
		panel.add(ponto1);
		
		JLabel ponto2 = new JLabel(crystalvazio);
		if (flagc2==true) {
		
			ponto2.setIcon(crystal);
			flagc2=false;
		}
			
		ponto2.setBounds(340, 0, 90, 90);
		panel.add(ponto2);
		
		JLabel ponto3 = new JLabel(crystalvazio);
		if (flagc3==true) {
			
			ponto3.setIcon(crystal);
			flagc3=false;
		}
		ponto3.setBounds(440, 20, 90, 90);
		panel.add(ponto3);
		
		
		JLabel resume = new JLabel(resumei);
		resume.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Nivel1 lvl1 = new Nivel1();
				Nivel2 lvl2 = new Nivel2();
				Nivel3 lvl3 = new Nivel3();
				Nivel4 lvl4 = new Nivel4();
				Nivel5 lvl5 = new Nivel5();
				MenuClear clear =new MenuClear();
				switch(contnivel) {
				case 1:
				
					
					
				
					
						
						
					
					
					Nivel2.frame.setVisible(true);
					Nivel1.frame .setVisible(false);
					clear.setVisible(false);
					flagniveis=true;
					break;
				case 2:
					Nivel2.frame.setVisible(false);
					dispose();
					Nivel3.frame.setVisible(true);
					break;
				case 3:
					Nivel3.frame.setVisible(false);
					dispose();
					Nivel4.frame.setVisible(true);
					break;
				case 4:
					Nivel4.frame.setVisible(false);
					dispose();
					Nivel5.frame.setVisible(true);
					break;
				case 5:
					Nivel5.frame.setVisible(false);
					dispose();
					break;
				}
				
				MenuClear menu =new MenuClear();
				menu.setVisible(false);
				dispose();
				
				
			}
		});
		resume.setBounds(420, 130, 90, 90);
		panel.add(resume);
	
		
		
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE) {
					System.exit(0);
				}
			}
		});
	}
}
