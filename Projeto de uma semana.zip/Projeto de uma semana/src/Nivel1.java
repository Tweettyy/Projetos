import javax.swing.*;
import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.awt.geom.Area;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Window.Type;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

public class Nivel1 extends JFrame {

	//Variaveis
	private JPanel contentPane;
	int dire�ao=2;
	boolean flag=false;
	public static Nivel1 frame = new Nivel1();
	
	ImageIcon morte=new ImageIcon(Nivel1.class.getResource("explosao.gif"));
	ImageIcon parede =new ImageIcon(Nivel1.class.getResource("black.jpg"));
	ImageIcon spikecima=new ImageIcon(Nivel1.class.getResource("spikeu.png"));
	ImageIcon spikebaixo=new ImageIcon(Nivel1.class.getResource("spiked.png"));
	ImageIcon portal=new ImageIcon(Nivel1.class.getResource("portalroxo.gif"));
	ImageIcon restarti=new ImageIcon(Nivel1.class.getResource("restart2.png"));
	ImageIcon pontos=new ImageIcon(Nivel1.class.getResource("pontos.gif"));
	ImageIcon estrelavazia=new ImageIcon(Nivel1.class.getResource("star.png"));
	ImageIcon estrela=new ImageIcon(Nivel1.class.getResource("star_1.png"));
	ImageIcon menu=new ImageIcon(Nivel1.class.getResource("list.png"));
	ImageIcon player1=new ImageIcon(Nivel2.class.getResource("player1.png"));

	

	
	//Frame
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					frame.setUndecorated(true);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	//Intersects
	public boolean intersetscima(JLabel player, JPanel panel) {
		Area area1 = new Area(player.getBounds());
		Area area2= new Area(panel.getBounds());
		
		return area1.intersects(area2.getBounds());
	}
	public boolean intersetsbaixo(JLabel player, JPanel panel_1) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(panel_1.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersetsesquerda(JLabel player, JPanel panel_6) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(panel_6.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersetsdireita(JLabel player, JPanel panel_10) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(panel_10.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersetsspikes(JLabel player, JLabel spike) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(spike.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean Fim(JLabel player, JLabel fim) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(fim.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	public boolean intersectpontos(JLabel player, JLabel ponto1) {
		Area areaLb1 = new Area(player.getBounds());
		Area areaLb2= new Area(ponto1.getBounds());
		return areaLb1.intersects(areaLb2.getBounds2D());
	}
	

	//Cria�ao 
	public Nivel1() {
		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setIconImage(estrela.getImage());
		setBounds(320, 0, 800, 900);
		contentPane = new JPanel();
		
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lista = new JLabel(menu);
		lista.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//System.exit(0);
				
				MenuPausa pausa=new MenuPausa();
//				frame.setVisible(false);
				pausa.setVisible(true);
				pausa.setBackground(new Color(1.0f,1.0f,1.0f,0.2f));


				
			}
		});
		lista.setBackground(Color.WHITE);
		lista.setBounds(740, 10, 40, 40);
		contentPane.add(lista);
		
		JLabel estrela3 = new JLabel(estrelavazia);
		estrela3.setBackground(Color.WHITE);
		estrela3.setBounds(400, 10, 40, 40);
		contentPane.add(estrela3);
		
		JLabel estrela1 = new JLabel(estrelavazia);
		estrela1.setBackground(Color.WHITE);
		estrela1.setBounds(319, 10, 40, 40);
		contentPane.add(estrela1);
		
		JLabel estrela2 = new JLabel(estrelavazia);
		estrela2.setBackground(Color.WHITE);
		estrela2.setBounds(360, 10, 40, 40);
		contentPane.add(estrela2);
		
		

		JLabel level = new JLabel("Level: 1");
		level.setFont(new Font("Buxton Sketch", Font.BOLD | Font.ITALIC, 25));
		level.setForeground(Color.WHITE);
		level.setHorizontalAlignment(SwingConstants.CENTER);
		level.setBounds(20, 10, 100, 50);
		contentPane.add(level);
		
		if(Menu.player==1) {
			 player1=new ImageIcon(Nivel2.class.getResource("player1.png"));
		}
		if(Menu.player==2){
			 player1=new ImageIcon(Nivel2.class.getResource("player2.png"));
		}
		if(Menu.player==3){
			 player1=new ImageIcon(Nivel2.class.getResource("player3.png"));//so funciona este
		}
		else{
			 player1=new ImageIcon(Nivel2.class.getResource("player4.png"));
		}
		
		JLabel player = new JLabel(player1);
		player.setBounds(700, 800, 60, 60);
		contentPane.add(player);
		
		
		
		JLabel ponto1 = new JLabel(pontos);
		ponto1.setBackground(Color.WHITE);
		ponto1.setBounds(715, 510, 35, 35);
		contentPane.add(ponto1);
		
		JLabel ponto2 = new JLabel(pontos);
		ponto2.setBackground(Color.WHITE);
		ponto2.setBounds(200, 110, 35, 35);
		contentPane.add(ponto2);
		
		JLabel ponto3 = new JLabel(pontos);
		ponto3.setBackground(Color.WHITE);
		ponto3.setBounds(430, 355, 35, 35);
		contentPane.add(ponto3);
		
		
		JLabel restart = new JLabel(restarti);
		restart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				player.setLocation(700, 800);
				estrela1.setIcon(estrelavazia);
				estrela2.setIcon(estrelavazia);
				estrela3.setIcon(estrelavazia);
				ponto1.setVisible(true);
				ponto2.setVisible(true);
				ponto3.setVisible(true);
			}
		});
		restart.setBackground(Color.WHITE);
		restart.setBounds(680, 10, 40, 40);
		contentPane.add(restart);
		
		JLabel parede7 = new JLabel(parede);
		parede7.setBackground(Color.BLACK);
		parede7.setBounds(780, 200, 20, 680);
		contentPane.add(parede7);
		
		JLabel parede1 = new JLabel(parede);
		parede1.setBounds(0, 0, 1440, 100);
		contentPane.add(parede1);
		
		JLabel parede2 = new JLabel(parede);
		parede2.setBounds(500, 100, 300, 100);
		contentPane.add(parede2);
		
		JLabel parede3 = new JLabel(parede);
		parede3.setBounds(400, 400, 400, 100);
		contentPane.add(parede3);
		
		JLabel parede4 = new JLabel(parede);
		parede4.setBounds(0, 800, 200, 100);
		contentPane.add(parede4);
		
		JLabel parede6 = new JLabel(parede);
		parede6.setBounds(0, 100, 20, 700);
		contentPane.add(parede6);
		
		JLabel parede8 = new JLabel(parede);
		parede8.setBounds(200, 880, 700, 20);
		contentPane.add(parede8);
		
		
		JLabel fim=new JLabel(portal);
		fim.setBounds(670,211,90,90);
		contentPane.add(fim);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.CYAN);
		panel.setBounds(400, 500, 380, 5);
		contentPane.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.CYAN);
		panel_1.setBounds(200, 875, 600, 5);
		contentPane.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.CYAN);
		panel_2.setBounds(-100, 100, 600, 5);
		contentPane.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.CYAN);
		panel_3.setBounds(500, 200, 600, 5);
		contentPane.add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.CYAN);
		panel_4.setBounds(20, 795, 180, 5);
		contentPane.add(panel_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.CYAN);
		panel_5.setBounds(400, 395, 600, 5);
		contentPane.add(panel_5);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(Color.CYAN);
		panel_6.setBounds(20, 100, 5, 800);
		contentPane.add(panel_6);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(Color.CYAN);
		panel_7.setBounds(200, 795, 5, 800);
		contentPane.add(panel_7);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(Color.CYAN);
		panel_8.setBounds(395, 395, 5, 110);
		contentPane.add(panel_8);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBackground(Color.CYAN);
		panel_9.setBounds(495, 100, 5, 105);
		contentPane.add(panel_9);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBackground(Color.CYAN);
		panel_10.setBounds(775, 200, 5, 700);
		contentPane.add(panel_10);
		
		
		
		JLabel spike = new JLabel(spikecima);
		spike.setBounds(30, 745, 50, 50);
		contentPane.add(spike);
		
		JLabel spike2 = new JLabel(spikecima);
		spike2.setBounds(80, 745, 50, 50);
		contentPane.add(spike2);
		
		JLabel spike3 = new JLabel(spikecima);
		spike3.setBounds(130, 745, 50, 50);
		contentPane.add(spike3);
		
		JLabel spike4 = new JLabel(spikebaixo);
		spike4.setBounds(30, 95, 50, 50);
		contentPane.add(spike4);
		
		JLabel spike5 = new JLabel(spikebaixo);
		spike5.setBounds(80, 95, 50, 50);
		contentPane.add(spike5);
		
		JLabel spike6 = new JLabel(spikebaixo);
		spike6.setBounds(130, 95, 50, 50);
		contentPane.add(spike6);
		
		
		
		JLabel death=new JLabel(morte);
		death.setBounds(player.getX(),player.getY(),500,500);
		death.setVisible(false);
		contentPane.add(death);
		
		
		
		
		//Timer
		Timer timer=new Timer();
		TimerTask task =new TimerTask() {
			public void run() {
				if (MenuPausa.flagrestart==true) {
					player.setLocation(700, 800);
					estrela1.setIcon(estrelavazia);
					estrela2.setIcon(estrelavazia);
					estrela3.setIcon(estrelavazia);
					ponto1.setVisible(true);
					ponto2.setVisible(true);
					ponto3.setVisible(true);
				
					MenuPausa.flagrestart=false;
				}
				
                if (intersectpontos(player,ponto1)) {
                	
                	MenuClear.flagc1=true;
					ponto1.setVisible(false);
					estrela1.setIcon(estrela);
				}
                if (intersectpontos(player,ponto2)) {
                	MenuClear.flagc2=true;
                    ponto2.setVisible(false);
                    estrela2.setIcon(estrela);

                }
                if (intersectpontos(player,ponto3)) {
                	MenuClear.flagc3=true;
					ponto3.setVisible(false);
					estrela3.setIcon(estrela);
				}
                if (intersetsspikes(player,spike)||intersetsspikes(player,spike2)||intersetsspikes(player,spike3)||intersetsspikes(player,spike4)||intersetsspikes(player,spike5)||intersetsspikes(player,spike6)) {
					player.setLocation(player.getX(), player.getY()-5);
					player.setVisible(false);
					dire�ao=2;
					death.setLocation(player.getX()-150, player.getY()-200);//O IF DEVIA TAR FORA DO IF(cima) MA COMO ESTA MUITO RAPIDO DEIXEI SNAO N SE VIA
					death.setVisible(true);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					death.setVisible(false);
					player.setLocation(700, 800);
					player.setVisible(true);
					estrela1.setIcon(estrelavazia);
					estrela2.setIcon(estrelavazia);
					estrela3.setIcon(estrelavazia);
					ponto1.setVisible(true);
					ponto2.setVisible(true);
					ponto3.setVisible(true);		
				}
                if (Fim(player,fim)) {
                	
					timer.cancel();
			        MenuClear.contnivel=1;
			       MenuClear clear=new MenuClear();
			       clear.setVisible(true);
			       clear.setBackground(new Color(1.0f,1.0f,1.0f,0.2f));
					
					
				}
                
				switch(dire�ao) {
				
				case 1:
					
					
					if(intersetscima(player,panel) ||intersetscima(player,panel_2) ||intersetscima(player,panel_3) ) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX(), player.getY()+5);
						
						
						
					}
					else {
						player.setLocation(player.getX(), player.getY()-5);
					}
					
					break;
				case 2:
					
					if(intersetsbaixo(player,panel_1)||intersetsbaixo(player,panel_5)||intersetsbaixo(player,panel_4)) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX(), player.getY()-5);
					
					}
					
					else {
					       player.setLocation(player.getX(), player.getY()+5);
					}
					break;
				case 3:
					
					if(intersetsesquerda(player,panel_6)||intersetsesquerda(player,panel_7)) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX()+1, player.getY());
						
					}
					else {
					      player.setLocation(player.getX()-5, player.getY());
					break;
					}
				case 4:
					
					if(intersetsdireita(player,panel_8)||intersetsdireita(player,panel_9)||intersetsdireita(player,panel_10)) {
						flag=false;
						dire�ao=0;
						player.setLocation(player.getX()-1, player.getY());	
						
					}
					else {
					     player.setLocation(player.getX()+5, player.getY());	
					}
					break;
				}	
			}
			
		};
		
		//Key
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent ke) {
				if (flag==false) {
					
			
				if ((ke.getKeyCode()==KeyEvent.VK_W)||(ke.getKeyCode()==KeyEvent.VK_UP)) {
					dire�ao=1;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);	
				}
				if ((ke.getKeyCode()==KeyEvent.VK_S)||(ke.getKeyCode()==KeyEvent.VK_DOWN)) {
					dire�ao=2;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);
					
				}
				if ((ke.getKeyCode()==KeyEvent.VK_A)||(ke.getKeyCode()==KeyEvent.VK_LEFT)) {
					dire�ao=3;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);
				}
				if ((ke.getKeyCode()==KeyEvent.VK_D)||(ke.getKeyCode()==KeyEvent.VK_RIGHT)) {
					dire�ao=4;
					flag=true;
					timer.scheduleAtFixedRate(task, 0, 2);
				}
				if (ke.getKeyCode()==KeyEvent.VK_ESCAPE) {
					timer.cancel();
					System.exit(0);
				}
				}
			}
		});


	}

	
}
