import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.Icon;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuPausa extends JFrame {

	ImageIcon menui=new ImageIcon(Nivel2.class.getResource("listaneon.png"));
	ImageIcon restarti=new ImageIcon(Nivel2.class.getResource("restartneon.png"));
	ImageIcon resumei=new ImageIcon(Nivel2.class.getResource("resume.png"));
	public static boolean flagrestart=false;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPausa frame = new MenuPausa();
					frame.setUndecorated(true);
					frame.setBackground(new Color(1.0f,1.0f,1.0f,0.2f));
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuPausa() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(283, 0, 800, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0f, 0f, 0f,0.7f));
		panel.setBounds(0, 400, 800, 200);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel menu = new JLabel(menui);
		menu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		menu.setBounds(190, 99, 90, 90);
		panel.add(menu);
		
		JLabel restart = new JLabel(restarti);
		restart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuPausa menu =new MenuPausa();
				menu.setVisible(false);
				dispose();
				flagrestart=true;
			}
		});
		restart.setBounds(340, 99, 90, 90);
		panel.add(restart);
		
		JLabel resume = new JLabel(resumei);
		resume.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuPausa menu =new MenuPausa();
				menu.setVisible(false);
				dispose();
			}
		});
		resume.setBounds(490, 99, 90, 90);
		panel.add(resume);
		
		JLabel titulo = new JLabel((Icon) null);
		titulo.setBounds(240, -10, 289, 90);
		panel.add(titulo);
		titulo.setForeground(new Color(0, 255, 255));
		titulo.setFont(new Font("Buxton Sketch", Font.PLAIN, 75));
		titulo.setText("Pausado!");
		
		
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE) {
					System.exit(0);
				}
			}
		});
	}
}
